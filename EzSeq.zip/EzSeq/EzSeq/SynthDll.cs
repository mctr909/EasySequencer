﻿using System;
using System.Runtime.InteropServices;

namespace EzSeq {
    internal class SynthDll : IDisposable {

        [DllImport("Synth.dll")]
        static extern IntPtr synth_setup(
            IntPtr filePath,
            int sampleRate,
            int bits,
            int bufferLength,
            int bufferCount
        );
        [DllImport("Synth.dll")]
        static extern void synth_close();
        [DllImport("Synth.dll")]
        static extern void send_message(byte port, IntPtr pMsg);

        IntPtr mpMessage;

        public SynthDll() {
            mpMessage = Marshal.AllocHGlobal(1024);
        }

        public void Dispose() {
            synth_close();
            Marshal.FreeHGlobal(mpMessage);
        }

        public void Close() {
            synth_close();
        }

        public void Setup(string wavetablePath, int sampleRate = 44100, int bits = 16, int bufferLength = 1024, int bufferCount = 8) {
            synth_setup(
                Marshal.StringToHGlobalAuto(wavetablePath),
                sampleRate,
                bits,
                bufferLength,
                bufferCount
            );
        }

        public void Send(byte port, byte[] msg) {
            Marshal.Copy(msg, 0, mpMessage, msg.Length);
            send_message(port, mpMessage);
        }
    }
}
