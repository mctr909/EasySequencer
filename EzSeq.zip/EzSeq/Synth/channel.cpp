#include <math.h>
#include <string.h>

#include "channel.h"
#include "sampler.h"
#include "system_values.h"

Channel::Channel(int32 port, int32 number) {
    this->port = port;
    this->number = number;
    setName(L"");
    pWaveL = (double*)calloc(SystemValues.buffer_length, sizeof(double));
    pWaveR = (double*)calloc(SystemValues.buffer_length, sizeof(double));
    mpDelayL = (double*)calloc(SystemValues.sample_rate, sizeof(double));
    mpDelayR = (double*)calloc(SystemValues.sample_rate, sizeof(double));
    init();
}

Channel::~Channel() {
    if (NULL != strName) {
        free(strName);
    }
    if (NULL != pWaveL) {
        free(pWaveL);
    }
    if (NULL != pWaveR) {
        free(pWaveR);
    }
    if (NULL != mpDelayL) {
        free(mpDelayL);
    }
    if (NULL != mpDelayR) {
        free(mpDelayR);
    }
}

void
Channel::setName(const WCHAR* name) {
    setName((LPWSTR)name);
}

void
Channel::setName(STRING name) {
    if (NULL != strName) {
        free(strName);
    }
    strName = (LPWSTR)calloc(lstrlenW(name), 1);
    if (NULL != strName) {
        lstrcpyW(strName, name);
    }
}

void
Channel::setPan(double pan) {
    params.pan = pan;
    panRe = cos(atan(1) * pan) * sqrt(2) / 2;
    panIm = sin(atan(1) * pan) * sqrt(2) / 2;
}

void
Channel::init() {
    params.bank_msb = 0;
    params.bank_lsb = 0;
    prog_chg(0);

    params.pitch = 1.0;
    params.transpose = 0;
    params.damper = false;

    params.vol = -3;
    params.exp = -3;
    setPan(0.0);
    params.rev = 0.0;
    params.cho = 0.0;
    params.del = 0.0;
    params.fc = 1.0;
    params.fq = 0.0;
    params.vib_depth = 100;
    params.vib_rate = 4.0;
    params.vib_delay = 50;
    params.cho_depth = 10;
    params.cho_rate = 0.5;
    params.del_time = 100;
    params.del_cross = 0.25;

    vibDepth = pow(2.0, params.vib_depth / 1200.0);
    vibRate = params.vib_rate * SystemValues.delta_time;
    vibDelay = SystemValues.delta_time * 1000 / params.vib_delay;

    mAmp = pow(10.0, (params.vol + params.exp) / 20.0);
    mChoRate = params.cho_rate * SystemValues.delta_time;
    mChoDepth = (int)(params.cho_depth * SystemValues.sample_rate * 0.001);
    mDelTime = (int)(params.del_time * SystemValues.sample_rate * 0.001);
}

void
Channel::ctrl_chg(E_CTRL type, byte* p_value) {
    switch (type) {
    case E_CTRL::BANK_LSB:
        params.bank_lsb = *p_value;
        break;
    case E_CTRL::BANK_MSB:
        params.bank_msb = *p_value;
        break;
    case E_CTRL::VOL:
        params.vol = *(double*)p_value;
        mAmp = pow(10.0, (params.vol + params.exp) / 20.0);
        break;
    case E_CTRL::EXP:
        params.exp = *(double*)p_value;
        mAmp = pow(10.0, (params.vol + params.exp) / 20.0);
        break;
    case E_CTRL::PAN:
        setPan(*(double*)p_value);
        break;
    case E_CTRL::REV:
        params.rev = *(double*)p_value;
        break;
    case E_CTRL::CHO:
        params.cho = *(double*)p_value;
        break;
    case E_CTRL::DEL:
        params.del = *(double*)p_value;
        break;
    case E_CTRL::FC:
        params.fc = *(double*)p_value;
        break;
    case E_CTRL::FQ:
        params.fq = *(double*)p_value;
        break;
    case E_CTRL::DAMPER:
        params.damper = *p_value;
        if (!params.damper) {
            for (int32 i = 0; i < 128; i++) {
                if (E_KEYSTATE::DAMPER == mKeyboard[i]) {
                    mKeyboard[i] = E_KEYSTATE::FREE;
                }
            }
            for (int32 i = 0; i < SAMPLER_COUNT; i++) {
                Sampler* p_smpl = SystemValues.ppSampler[i];
                if (p_smpl->port = port && p_smpl->channel == number &&
                    EG_STATE::DUMPER == p_smpl->egValue.state) {
                    p_smpl->egValue.state = EG_STATE::RELEASE;
                }
            }
        }
        break;
    case E_CTRL::VIB_DEPTH:
        params.vib_depth = *(int32*)p_value;
        vibDepth = pow(2.0, params.vib_depth / 1200.0);
        break;
    case E_CTRL::VIB_RATE:
        params.vib_rate = *(double*)p_value;
        vibRate = params.vib_rate * SystemValues.delta_time;
        break;
    case E_CTRL::VIB_DELAY:
        params.vib_delay = *(int32*)p_value;
        if (0 == params.vib_delay) {
            vibDelay = 1.0;
        } else {
            vibDelay = SystemValues.delta_time * 1000 / params.vib_delay;
        }
        break;

    case E_CTRL::CHO_DEPTH:
        params.cho_depth = *(int32*)p_value;
        mChoDepth = (int)(params.cho_depth * SystemValues.sample_rate * 0.001);
        break;
    case E_CTRL::CHO_RATE:
        params.cho_rate = *(double*)p_value;
        mChoRate = params.cho_rate * SystemValues.delta_time;
        break;
    case E_CTRL::DEL_TIME:
        params.del_time = *(int32*)p_value;
        mDelTime = (int)(params.del_time * SystemValues.sample_rate * 0.001);
        break;
    case E_CTRL::DEL_CROSS:
        params.del_cross = *(double*)p_value;
        break;
    case E_CTRL::TRANSPOSE:
        params.transpose = *(int32*)p_value;
        break;
    case E_CTRL::CHANNEL_NAME:
        setName((STRING)p_value);
        break;
    }
}

void
Channel::prog_chg(byte number) {
    params.prog_num = number;
}

void
Channel::pitch_bend(byte* p_value) {
    params.pitch = *(double*)p_value;
}

void
Channel::onkey(byte note, byte velocity) {
    if (0 == velocity) {
        if (E_KEYSTATE::PRESS == mKeyboard[note]) {
            mKeyboard[note] = params.damper ? E_KEYSTATE::DAMPER : E_KEYSTATE::FREE;
        }
        for (int32 i = 0; i < SAMPLER_COUNT; i++) {
            Sampler* p_smpl = SystemValues.ppSampler[i];
            if (p_smpl->port = port && p_smpl->channel == number && p_smpl->note == note &&
                EG_STATE::PRESS == p_smpl->egValue.state) {
                p_smpl->egValue.state = params.damper ? EG_STATE::DUMPER : EG_STATE::RELEASE;
            }
        }
    } else {
        mKeyboard[note] = E_KEYSTATE::PRESS;
        for (int32 i = 0; i < SAMPLER_COUNT; i++) {
            Sampler* p_smpl = SystemValues.ppSampler[i];
            if (p_smpl->port = port && p_smpl->channel == number && p_smpl->note == note &&
                EG_STATE::PRESS <= p_smpl->egValue.state) {
                p_smpl->egValue.state = EG_STATE::PURGE;
            }
        }
        for (int32 i = 0; i < SAMPLER_COUNT; i++) {
            Sampler* p_smpl = SystemValues.ppSampler[i];
            if (EG_STATE::FREE == p_smpl->egValue.state) {
                p_smpl->egValue.state = EG_STATE::RESERVED;
                p_smpl->onkey(port, number, note, velocity);
                p_smpl->egValue.state = EG_STATE::PRESS;
            }
        }
        if (E_STATE::FREE == mState) {
            mState = E_STATE::STANDBY;
        }
    }
}

void
Channel::step() {
    if (E_STATE::FREE == mState) {
        return;
    }
    const double rms_delta = SystemValues.delta_time * SystemValues.delta_time * 6.8 * 6.8 / RMS_TIME;
    const double rms_idelta = 1.0 - rms_delta;
    for (int32 i = 0; i < SystemValues.buffer_length; i++) {
        auto output_l = pWaveL[i] * mCurAmp;
        auto output_r = pWaveR[i] * mCurAmp;
        mCurAmp += (mAmp - mCurAmp) * TRANSITION_SPEED;
        pWaveL[i] = 0.0;
        pWaveR[i] = 0.0;

        params.rmsL = params.rmsL * rms_idelta + (output_l * output_l) * rms_delta;
        params.rmsR = params.rmsR * rms_idelta + (output_r * output_r) * rms_delta;
        SystemValues.p_wave_l[i] += output_l;
        SystemValues.p_wave_r[i] += output_r;
    }
    if (E_STATE::STANDBY == mState) {
        if (ACTIVE_THRESHOLD <= params.rmsL || ACTIVE_THRESHOLD <= params.rmsR) {
            mState = E_STATE::ACTIVE;
        }
    } else {
        if (params.rmsL < PURGE_THRESHOLD && params.rmsR < PURGE_THRESHOLD) {
            mState = E_STATE::FREE;
        }
    }
}