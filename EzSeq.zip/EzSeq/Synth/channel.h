#ifndef __CHANNEL_H__
#define __CHANNEL_H__

#include "type.h"

enum struct E_CTRL {
    BANK_LSB,
    BANK_MSB,
    VOL,
    EXP,
    PAN,
    REV,
    CHO,
    DEL,
    FC,
    FQ,
    DAMPER,
    VIB_DEPTH,
    VIB_RATE,
    VIB_DELAY,
    CHO_DEPTH,
    CHO_RATE,
    DEL_TIME,
    DEL_CROSS,
    TRANSPOSE,
    CHANNEL_NAME
};

typedef struct CHANNEL_PARAMS {
    byte prog_num;
    byte bank_msb;
    byte bank_lsb;
    sbyte transpose;

    bool damper;
    double pitch;

    double vol;
    double exp;
    double pan;
    double rev;
    double cho;
    double del;
    double fc;
    double fq;

    int32 cho_depth;
    int32 vib_depth;
    int32 vib_delay;
    int32 del_time;
    double cho_rate;
    double vib_rate;
    double del_cross;

    double rmsL;
    double rmsR;
} CHANNEL_PARAMS;

class Channel {
public:
    int32 port = -1;
    int32 number = -1;
    STRING strName = NULL;
    CHANNEL_PARAMS params = { 0 };

    double *pWaveL = NULL;
    double *pWaveR = NULL;

    double panRe = 0.0;
    double panIm = 0.0;

    double vibDepth = 0.0;
    double vibRate = 0.0;
    double vibDelay = 0.0;

private:
    enum struct E_STATE : byte {
        FREE,
        STANDBY,
        ACTIVE
    };
    enum struct E_KEYSTATE : byte {
        FREE,
        PRESS,
        DAMPER
    };
    E_STATE mState = E_STATE::FREE;
    E_KEYSTATE mKeyboard[128] = { E_KEYSTATE::FREE };
    double* mpDelayL = NULL;
    double* mpDelayR = NULL;
    double mAmp = 0.0;
    double mCurAmp = 0.0;
    double mChoRate = 0.0;
    int32 mChoDepth = 0;
    int32 mDelTime = 0;

private:
    Channel() {}

public:
    Channel(int32 port, int32 number);
    ~Channel();

private:
    void setName(const WCHAR* name);
    void setName(STRING name);
    void setPan(double pan);

public:
    void init();
    void ctrl_chg(E_CTRL type, byte* p_value);
    void prog_chg(byte number);
    void pitch_bend(byte* p_value);
    void onkey(byte note, byte velocity);
    void step();
};

#endif /* __CHANNEL_H__ */