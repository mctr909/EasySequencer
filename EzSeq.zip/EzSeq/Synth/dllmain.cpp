#include "dllmain.h"
#include "system_values.h"

#include <stdio.h>
#include <stdlib.h>
#include <dshow.h>
#include <mmsystem.h>

#pragma comment(lib, "strmiids")
#pragma comment(lib, "winmm.lib")

/******************************************************************************/
void release();
void enumerate_devices();
void display_device_info(IEnumMoniker*);

/******************************************************************************/
void release() {
    if (NULL != SystemValues.p_wave_table) {
        free(SystemValues.p_wave_table);
    }
    if (NULL != SystemValues.p_wave_l) {
        free(SystemValues.p_wave_l);
    }
    if (NULL != SystemValues.p_wave_r) {
        free(SystemValues.p_wave_r);
    }
    for (int i = 0; i < SAMPLER_COUNT; i++) {
        if (NULL != SystemValues.ppSampler[i]) {
            free(SystemValues.ppSampler[i]);
        }
    }
    for (int i = 0; i < CHANNEL_COUNT; i++) {
        if (NULL != SystemValues.ppChannel[i]) {
            free(SystemValues.ppChannel[i]);
        }
    }
}

void enumerate_devices() {
    REFGUID CATEGORY = CLSID_AudioRendererCategory;
    // Create the System Device Enumerator.
    ICreateDevEnum* p_dev_enum;
    HRESULT hr = CoCreateInstance(CLSID_SystemDeviceEnum, NULL,
        CLSCTX_INPROC_SERVER, IID_PPV_ARGS(&p_dev_enum));
    if (SUCCEEDED(hr)) {
        // Create an enumerator for the category.
        IEnumMoniker* p_enum = NULL;
        hr = p_dev_enum->CreateClassEnumerator(CATEGORY, &p_enum, 0);
        if (hr == S_FALSE) {
            hr = VFW_E_NOT_FOUND;  // The category is empty. Treat as an error.
        } else {
            display_device_info(p_enum);
        }
        p_dev_enum->Release();
    }
    {
        uint32 devs = waveOutGetNumDevs();
        WAVEOUTCAPSW caps;
        waveOutGetDevCapsW(-1, &caps, sizeof(caps));
    }
}

void display_device_info(IEnumMoniker* p_enum) {
    IMoniker* p_moniker = NULL;
    int32 device_count = 0;
    while (p_enum->Next(1, &p_moniker, NULL) == S_OK) {
        device_count++;
        IPropertyBag* p_prop_bag;
        HRESULT hr = p_moniker->BindToStorage(0, 0, IID_PPV_ARGS(&p_prop_bag));
        if (FAILED(hr)) {
            p_moniker->Release();
            continue;
        }

        VARIANT var;
        VariantInit(&var);

        hr = p_prop_bag->Read(L"FriendlyName", &var, 0);
        if (SUCCEEDED(hr)) {
            printf("%S\n", var.bstrVal);
            VariantClear(&var);
        }

        p_prop_bag->Release();
        p_moniker->Release();
    }
}

/******************************************************************************/
byte* WINAPI
synth_setup(
    STRING file_path,
    int32 sample_rate,
    int32 bits,
    int32 buffer_length,
    int32 buffer_count
) {
    release();

    SystemValues.sample_rate = sample_rate;
    SystemValues.bits = bits;
    SystemValues.buffer_length = buffer_length;
    SystemValues.buffer_count = buffer_count;
    SystemValues.delta_time = 1.0 / sample_rate;
    SystemValues.p_wave_l = (double*)calloc(buffer_length, sizeof(double));
    SystemValues.p_wave_r = (double*)calloc(buffer_length, sizeof(double));
    for (int i = 0; i < SAMPLER_COUNT; i++) {
        SystemValues.ppSampler[i] = new Sampler();
    }
    for (int i = 0; i < CHANNEL_COUNT; i++) {
        SystemValues.ppChannel[i] = new Channel(i / MIDI_CHANNELS, i % MIDI_CHANNELS);
    }

    return NULL;
}

void WINAPI
synth_close() {
    release();
}

void WINAPI
send_message(byte port, byte* p_msg) {
}
