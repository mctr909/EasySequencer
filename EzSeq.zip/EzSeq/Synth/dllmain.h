#ifndef __DLLMAIN_H__
#define __DLLMAIN_H__

#include "type.h"

/******************************************************************************/
#ifdef __cplusplus
extern "C" {
#endif
    __declspec(dllexport) byte* WINAPI synth_setup(
        STRING file_path,
        int32 sample_rate,
        int32 bits,
        int32 buffer_length,
        int32 buffer_count
    );
    __declspec(dllexport) void WINAPI synth_close();
    __declspec(dllexport) void WINAPI send_message(byte port, byte* p_msg);
#ifdef __cplusplus
}
#endif

#endif /* __DLLMAIN_H__ */