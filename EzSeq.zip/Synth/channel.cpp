#include <math.h>
#include <string.h>

#include "channel.h"
#include "sampler.h"
#include "system_values.h"

#define PURGE_THRESHOLD 0.0001
#define ACTIVE_THRESHOLD 0.001
#define RMS_TIME (0.3 * 0.3)

Channel::Channel(int32 port, int32 number) {
    this->port = port;
    this->number = number;
    setName(L"");
    pWaveL = (double*)calloc(SystemValues.buffer_length, sizeof(double));
    pWaveR = (double*)calloc(SystemValues.buffer_length, sizeof(double));
    mpDelayL = (double*)calloc(SystemValues.sample_rate, sizeof(double));
    mpDelayR = (double*)calloc(SystemValues.sample_rate, sizeof(double));
    init();
}

Channel::~Channel() {
    if (NULL != strName) {
        free(strName);
    }
    if (NULL != pWaveL) {
        free(pWaveL);
    }
    if (NULL != pWaveR) {
        free(pWaveR);
    }
    if (NULL != mpDelayL) {
        free(mpDelayL);
    }
    if (NULL != mpDelayR) {
        free(mpDelayR);
    }
}

void
Channel::setName(const WCHAR* name) {
    setName((LPWSTR)name);
}

void
Channel::setName(STRING name) {
    if (NULL != strName) {
        free(strName);
    }
    strName = (LPWSTR)calloc(lstrlenW(name), 1);
    if (NULL != strName) {
        lstrcpyW(strName, name);
    }
}

void
Channel::setPan(double pan) {
    this->pan = pan;
    panRe = cos(atan(1) * pan) * sqrt(2) / 2;
    panIm = sin(atan(1) * pan) * sqrt(2) / 2;
}

void
Channel::init() {
    bank_msb = 0;
    bank_lsb = 0;
    prog_chg(0);

    pitch = 1.0;

    transpose = 0;
    damper = false;

    vol = 100 / 127.0;
    exp = 100 / 127.0;
    setPan(0.0);
    rev = 0.0;
    cho = 0.0;
    del = 0.0;
    fc = 1.0;
    fq = 0.0;
    cho_depth = pow(2.0, 10 / 1200.0);
    cho_rate = 0.5 * SystemValues.delta_time;
    vib_depth = pow(2.0, 100 / 1200.0);
    vib_rate = 4.0 * SystemValues.delta_time;
    vib_delay = 0.05 * SystemValues.sample_rate;
    del_time = (int)(0.1 * SystemValues.sample_rate);
    del_cross = 0.25;
}

void
Channel::ctrl_chg(E_CTRL type, byte* p_value) {
    switch (type) {
    case E_CTRL::BANK_LSB:
        bank_lsb = *p_value;
        break;
    case E_CTRL::BANK_MSB:
        bank_msb = *p_value;
        break;
    case E_CTRL::VOL:
        vol = pow(10.0, *(double*)p_value / 20.0);
        break;
    case E_CTRL::EXP:
        exp = pow(10.0, *(double*)p_value / 20.0);
        break;
    case E_CTRL::PAN:
        setPan(*(double*)p_value);
        break;
    case E_CTRL::REV:
        rev = *(double*)p_value;
        break;
    case E_CTRL::CHO:
        cho = *(double*)p_value;
        break;
    case E_CTRL::DEL:
        del = *(double*)p_value;
        break;
    case E_CTRL::FC:
        fc = *(double*)p_value;
        break;
    case E_CTRL::FQ:
        fq = *(double*)p_value;
        break;
    case E_CTRL::DAMPER:
        damper = *p_value;
        if (!damper) {
            for (int32 i = 0; i < 128; i++) {
                if (E_KEYSTATE::DAMPER == keyboard[i]) {
                    keyboard[i] = E_KEYSTATE::FREE;
                }
            }
            for (int32 i = 0; i < SAMPLER_COUNT; i++) {
                Sampler* p_smpl = SystemValues.ppSampler[i];
                if (p_smpl->port = port && p_smpl->channel == number &&
                    EG_STATE::DUMPER == p_smpl->egValue.state) {
                    p_smpl->egValue.state = EG_STATE::RELEASE;
                }
            }
        }
        break;
    case E_CTRL::VIB_DEPTH:
        vib_depth = pow(2.0, *(int32*)p_value / 1200.0);
        break;
    case E_CTRL::VIB_RATE:
        vib_rate = *(double*)p_value * SystemValues.delta_time;
        break;
    case E_CTRL::VIB_DELAY:
        if (*(double*)p_value < SystemValues.delta_time) {
            vib_delay = 1.0;
        } else {
            vib_delay = *(double*)p_value * SystemValues.sample_rate;
        }
        break;

    case E_CTRL::CHO_DEPTH:
        cho_depth = pow(2.0, *(int32*)p_value / 1200.0);
        break;
    case E_CTRL::CHO_RATE:
        cho_rate = *(double*)p_value * SystemValues.delta_time;
        break;
    case E_CTRL::DEL_TIME:
        del_time = (int)(*(double*)p_value * SystemValues.sample_rate);
        break;
    case E_CTRL::DEL_CROSS:
        del_cross = *(double*)p_value;
        break;
    case E_CTRL::TRANSPOSE:
        transpose = *(int32*)p_value;
        break;
    case E_CTRL::CHANNEL_NAME:
        setName((STRING)p_value);
        break;
    }
}

void
Channel::prog_chg(byte number) {
    prog_num = number;
}

void
Channel::pitch_bend(byte* p_value) {
    pitch = *(double*)p_value;
}

void
Channel::onkey(byte note, byte velocity) {
    if (0 == velocity) {
        if (E_KEYSTATE::PRESS == keyboard[note]) {
            keyboard[note] = damper ? E_KEYSTATE::DAMPER : E_KEYSTATE::FREE;
        }
        for (int32 i = 0; i < SAMPLER_COUNT; i++) {
            Sampler* p_smpl = SystemValues.ppSampler[i];
            if (p_smpl->port = port && p_smpl->channel == number && p_smpl->note == note &&
                EG_STATE::PRESS == p_smpl->egValue.state) {
                p_smpl->egValue.state = damper ? EG_STATE::DUMPER : EG_STATE::RELEASE;
            }
        }
    } else {
        keyboard[note] = E_KEYSTATE::PRESS;
        for (int32 i = 0; i < SAMPLER_COUNT; i++) {
            Sampler* p_smpl = SystemValues.ppSampler[i];
            if (p_smpl->port = port && p_smpl->channel == number && p_smpl->note == note &&
                EG_STATE::PRESS <= p_smpl->egValue.state) {
                p_smpl->egValue.state = EG_STATE::PURGE;
            }
        }
        for (int32 i = 0; i < SAMPLER_COUNT; i++) {
            Sampler* p_smpl = SystemValues.ppSampler[i];
            if (EG_STATE::FREE == p_smpl->egValue.state) {
                p_smpl->egValue.state = EG_STATE::RESERVED;
                p_smpl->onkey(port, number, note, velocity);
                p_smpl->egValue.state = EG_STATE::PRESS;
            }
        }
        if (E_CHANNEL_STATE::FREE == state) {
            state = E_CHANNEL_STATE::STANDBY;
        }
    }
}

void
Channel::step() {
    if (E_CHANNEL_STATE::FREE == state) {
        return;
    }
    const double rms_delta = SystemValues.delta_time * SystemValues.delta_time * 6.8 * 6.8 / RMS_TIME;
    const double rms_idelta = 1.0 - rms_delta;
    for (int32 i = 0; i < SystemValues.buffer_length; i++) {
        auto output_l = pWaveL[i];
        auto output_r = pWaveR[i];
        pWaveL[i] = 0.0;
        pWaveR[i] = 0.0;

        rmsL = rmsL * rms_idelta + (output_l * output_l) * rms_delta;
        rmsR = rmsR * rms_idelta + (output_r * output_r) * rms_delta;
        SystemValues.p_wave_l[i] += output_l;
        SystemValues.p_wave_r[i] += output_r;
    }
    if (E_CHANNEL_STATE::STANDBY == state) {
        if (ACTIVE_THRESHOLD <= rmsL || ACTIVE_THRESHOLD <= rmsR) {
            state = E_CHANNEL_STATE::ACTIVE;
        }
    } else {
        if (rmsL < PURGE_THRESHOLD && rmsR < PURGE_THRESHOLD) {
            state = E_CHANNEL_STATE::FREE;
        }
    }
}