#ifndef __CHANNEL_H__
#define __CHANNEL_H__

#include "type.h"

enum struct E_CTRL {
    BANK_LSB,
    BANK_MSB,
    VOL,
    EXP,
    PAN,
    REV,
    CHO,
    DEL,
    FC,
    FQ,
    DAMPER,
    VIB_DEPTH,
    VIB_RATE,
    VIB_DELAY,
    CHO_DEPTH,
    CHO_RATE,
    DEL_TIME,
    DEL_CROSS,
    TRANSPOSE,
    CHANNEL_NAME
};

enum struct E_CHANNEL_STATE {
    FREE,
    STANDBY,
    ACTIVE
};

enum struct E_KEYSTATE {
    FREE,
    PRESS,
    DAMPER
};

class Channel {
public:
    int32 port = -1;
    int32 number = -1;
    STRING strName = NULL;
    E_CHANNEL_STATE state = E_CHANNEL_STATE::FREE;
    E_KEYSTATE keyboard[128] = { E_KEYSTATE::FREE };

    byte prog_num = 0;
    byte bank_msb = 0;
    byte bank_lsb = 0;

    double *pWaveL = NULL;
    double *pWaveR = NULL;
    double rmsL = 0.0;
    double rmsR = 0.0;
    double panRe = 0.0;
    double panIm = 0.0;

    int32 transpose = 0;
    double pitch = 0.0;
    bool damper = false;

    double vol = 0.0;
    double exp = 0.0;
    double pan = 0.0;
    double rev = 0.0;
    double cho = 0.0;
    double del = 0.0;
    double fc = 0.0;
    double fq = 0.0;
    double cho_depth = 0.0;
    double cho_rate = 0.0;
    double vib_depth = 0.0;
    double vib_rate = 0.0;
    double vib_delay = 0.0;
    int32 del_time = 0;
    double del_cross = 0.0;

private:
    double* mpDelayL = NULL;
    double* mpDelayR = NULL;

private:
    Channel() {}

public:
    Channel(int32 port, int32 number);
    ~Channel();

private:
    void setName(const WCHAR* name);
    void setName(STRING name);
    void setPan(double pan);

public:
    void init();
    void ctrl_chg(E_CTRL type, byte* p_value);
    void prog_chg(byte number);
    void pitch_bend(byte* p_value);
    void onkey(byte note, byte velocity);
    void step();
};

#endif /* __CHANNEL_H__ */