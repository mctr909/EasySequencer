#ifndef __EG_H__
#define __EG_H__

enum struct EG_STATE : char {
	FREE,
	RESERVED,
	PRESS,
	DUMPER,
	RELEASE,
	PURGE
};

typedef struct EG_PARAM {
	double amp_attack;
	double amp_decay;
	double amp_dumper;
	double amp_release;
	double amp_sustain;
	double vcf_attack;
	double vcf_decay;
	double vcf_dumper;
	double vcf_release;
	double vcf_sustain;
	double vcf_rise;
	double vcf_peak;
	double vcf_tail;
	double vcf_resonance;
	double pitch_attack;
	double pitch_decay;
	double pitch_dumper;
	double pitch_release;
	double pitch_rise;
	double pitch_peak;	
	double pitch_tail;
} EG_PARAM;

typedef struct EG_VALUE {
	EG_STATE state;
	char amp_ondecay;
	char vcf_ondecay;
	char pitch_ondecay;
	double amp;
	double vcf;
	double pitch;
} EG_VALUE;

inline void eg_step(const EG_PARAM &param, EG_VALUE *p_value) {
	switch(p_value->state) {
	case EG_STATE::PRESS:
		if (p_value->amp_ondecay) {
			p_value->amp += (param.amp_sustain - p_value->amp) * param.amp_decay;
		} else {
			p_value->amp += (1.0 - p_value->amp) * param.amp_attack;
			if (0.995 <= p_value->amp) {
				p_value->amp_ondecay = 1;
			}
		}
		if (p_value->vcf_ondecay) {
			p_value->vcf += (param.vcf_sustain - p_value->vcf) * param.vcf_decay;
		} else {
			p_value->vcf += (param.vcf_peak - p_value->vcf) * param.vcf_attack;
			if (param.vcf_peak*0.99 <= p_value->vcf && p_value->vcf <= param.vcf_peak*1.01) {
				p_value->vcf_ondecay = 1;
			}
		}
		if (p_value->pitch_ondecay) {
			p_value->pitch += (1.0 - p_value->pitch) * param.pitch_decay;
		} else {
			p_value->pitch += (param.pitch_peak - p_value->pitch) * param.pitch_attack;
			if (param.pitch_peak*0.99 <= p_value->pitch && p_value->pitch <= param.pitch_peak*1.01) {
				p_value->pitch_ondecay = 1;
			}			
		}
		break;
	case EG_STATE::DUMPER:
		p_value->amp -= p_value->amp * param.amp_dumper;
		p_value->vcf += (param.vcf_tail - p_value->vcf) * param.vcf_dumper;
		p_value->pitch += (param.pitch_tail - p_value->pitch) * param.pitch_dumper;
		break;
	case EG_STATE::RELEASE:
		p_value->amp -= p_value->amp * param.amp_release;
		p_value->vcf += (param.vcf_tail - p_value->vcf) * param.vcf_release;
		p_value->pitch += (param.pitch_tail - p_value->pitch) * param.pitch_release;
		break;
	case EG_STATE::PURGE:
		p_value->amp -= p_value->amp * 0.25;
		break;
	}
	if (EG_STATE::DUMPER <= p_value->state && p_value->amp < 0.001) {
		p_value->state = EG_STATE::FREE;
		p_value->amp_ondecay = 0;
		p_value->vcf_ondecay = 0;
		p_value->pitch_ondecay = 0;
	}
}

#endif //__EG_H__
