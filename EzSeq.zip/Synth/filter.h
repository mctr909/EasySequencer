#ifndef __FILTER_H__
#define __FILTER_H__

/******************************************************************************/
#define ADJUST_CUTOFF 0.975

#define PI        3.14159265
#define INV_FACT2 5.00000000e-01
#define INV_FACT3 1.66666667e-01
#define INV_FACT4 4.16666667e-02
#define INV_FACT5 8.33333333e-03
#define INV_FACT6 1.38888889e-03
#define INV_FACT7 1.98412698e-04
#define INV_FACT8 2.48015873e-05
#define INV_FACT9 2.75573192e-06

/******************************************************************************/
typedef struct FILTER {
    double cut;
    double res;
    double width;
    double gain;
    double a11;
    double a12;
    double a21;
    double a22;
    double b11;
    double b12;
    double b21;
    double b22;
} FILTER;

/******************************************************************************/
inline void filter_lpf(FILTER *p_filter, double input) {
    /** sin, cos�̋ߎ� **/
    double rad = p_filter->cut * PI * ADJUST_CUTOFF;
    double rad_2 = rad * rad;
    double c = INV_FACT8;
    c *= rad_2;
    c -= INV_FACT6;
    c *= rad_2;
    c += INV_FACT4;
    c *= rad_2;
    c -= INV_FACT2;
    c *= rad_2;
    c++;
    double s = INV_FACT9;
    s *= rad_2;
    s -= INV_FACT7;
    s *= rad_2;
    s += INV_FACT5;
    s *= rad_2;
    s -= INV_FACT3;
    s *= rad_2;
    s++;
    s *= rad;

    /** IIR���[�p�X�t�B���^ �p�����[�^�ݒ� **/
    double a = s / (p_filter->res * 4.0 + 1.0);
    double m = 1.0 / (a + 1.0);
    double ka1 = -2.0 * c * m;
    double kb1 = (1.0 - c) * m;
    double ka2 = (1.0 - a) * m;
    double kb2 = kb1 * 0.5;

    /** �t�B���^1�i�� **/
    double output =
          kb2 * input
        + kb1 * p_filter->b11
        + kb2 * p_filter->b12
        - ka1 * p_filter->a11
        - ka2 * p_filter->a12
    ;
    p_filter->b12 = p_filter->b11;
    p_filter->b11 = input;
    p_filter->a12 = p_filter->a11;
    p_filter->a11 = output;

    /** �t�B���^2�i�� **/
    input = output;
    output =
          kb2 * input
        + kb1 * p_filter->b21
        + kb2 * p_filter->b22
        - ka1 * p_filter->a21
        - ka2 * p_filter->a22
    ;
    p_filter->b22 = p_filter->b21;
    p_filter->b21 = input;
    p_filter->a22 = p_filter->a21;
    p_filter->a21 = output;
}

inline void filter_peak(FILTER* p_filter, double input) {
}

#endif /* __FILTER_H__ */