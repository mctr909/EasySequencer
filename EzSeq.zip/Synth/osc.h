#ifndef __OSC_H__
#define __OSC_H__

#define OSC_TABLE_LENGTH 128

const double OSC_TABLE_SIN[OSC_TABLE_LENGTH] = {
	0.00000, 0.04907, 0.09802, 0.14673, 0.19509, 0.24298, 0.29028, 0.33689,
	0.38268, 0.42756, 0.47140, 0.51410, 0.55557, 0.59570, 0.63439, 0.67156,
	0.70711, 0.74095, 0.77301, 0.80321, 0.83147, 0.85773, 0.88192, 0.90399,
	0.92388, 0.94154, 0.95694, 0.97003, 0.98079, 0.98918, 0.99518, 0.99880,
	1.00000, 0.99880, 0.99518, 0.98918, 0.98079, 0.97003, 0.95694, 0.94154,
	0.92388, 0.90399, 0.88192, 0.85773, 0.83147, 0.80321, 0.77301, 0.74095,
	0.70711, 0.67156, 0.63439, 0.59570, 0.55557, 0.51410, 0.47140, 0.42756,
	0.38268, 0.33689, 0.29028, 0.24298, 0.19509, 0.14673, 0.09802, 0.04907,
	 0.00000, -0.04907, -0.09802, -0.14673, -0.19509, -0.24298, -0.29028, -0.33689,
	-0.38268, -0.42756, -0.47140, -0.51410, -0.55557, -0.59570, -0.63439, -0.67156,
	-0.70711, -0.74095, -0.77301, -0.80321, -0.83147, -0.85773, -0.88192, -0.90399,
	-0.92388, -0.94154, -0.95694, -0.97003, -0.98079, -0.98918, -0.99518, -0.99880,
	-1.00000, -0.99880, -0.99518, -0.98918, -0.98079, -0.97003, -0.95694, -0.94154,
	-0.92388, -0.90399, -0.88192, -0.85773, -0.83147, -0.80321, -0.77301, -0.74095,
	-0.70711, -0.67156, -0.63439, -0.59570, -0.55557, -0.51410, -0.47140, -0.42756,
	-0.38268, -0.33689, -0.29028, -0.24298, -0.19509, -0.14673, -0.09802, -0.04907
};

typedef struct OSC {
	double delta;
	double pitch;
	double phase;
	double param;
	double time;
	double value;
	int wave_length;
	int loop_begin;
	int loop_length;
	short *p_wave;
} OSC;

inline void osc_pcm(OSC *p_osc) {
	double index_d = p_osc->time;
	p_osc->time += p_osc->pitch * p_osc->delta;
	if (p_osc->loop_length) {
		if ((p_osc->loop_begin + p_osc->loop_length) <= p_osc->time) {
			p_osc->time -= p_osc->loop_length;
		}
	} else {
		if (p_osc->wave_length <= p_osc->time) {
			p_osc->time = p_osc->wave_length;
			p_osc->value = p_osc->p_wave[p_osc->wave_length - 1] / 32768.0;
			return;
		}
	}
	int index_a = (int)index_d;
	double err = index_d - index_a;
	if (p_osc->wave_length <= index_a) {
		index_a -= p_osc->wave_length;
	}
	int index_b = index_a + 1;
	if (p_osc->wave_length == index_b) {
		index_b = 0;
	}
	p_osc->value = (p_osc->p_wave[index_a] * (1.0 - err) + p_osc->p_wave[index_b] * err) / 32768.0;
}
inline void osc_sin(OSC *p_osc) {
	if (p_osc->phase < 0.0) {
		p_osc->phase += 1.0;
	}
	double index_d = (p_osc->time + p_osc->phase) * OSC_TABLE_LENGTH;
	p_osc->time += p_osc->pitch * p_osc->delta;
	if (1.0 <= p_osc->time) {
		p_osc->time -= 1.0;
	}
	int index_a = (int)index_d;
	double err = index_d - index_a;
	if (OSC_TABLE_LENGTH <= index_a) {
		index_a -= OSC_TABLE_LENGTH;
	}
	int index_b = index_a + 1;
	if (OSC_TABLE_LENGTH == index_b) {
		index_b = 0;
	}
	p_osc->value = OSC_TABLE_SIN[index_a] * (1.0 - err) + OSC_TABLE_SIN[index_b] * err;
}
inline void osc_pwm(OSC *p_osc) {
	if (p_osc->phase < 0.0) {
		p_osc->phase += 1.0;
	}
	double value = 0.0;
	for (int i=8; 0<i; i--) {
		double time = p_osc->time + p_osc->phase;
		if (1.0 <= time) {
			time -= 1.0;
		}
		p_osc->time += p_osc->pitch * p_osc->delta * 0.125;
		if (1.0 <= p_osc->time) {
			p_osc->time -= 1.0;
		}
		if (time < p_osc->param) {
			value += 0.125;
		} else {
			value -= 0.125;
		}
	}
	p_osc->value = value;
}
inline void osc_saw(OSC *p_osc) {
	if (p_osc->phase < 0.0) {
		p_osc->phase += 1.0;
	}
	double value = 0.0;
	for (int i=8; 0<i; i--) {
		double time = p_osc->time + p_osc->phase;
		if (1.0 <= time) {
			time -= 1.0;
		}
		p_osc->time += p_osc->pitch * p_osc->delta * 0.125;
		if (1.0 <= p_osc->time) {
			p_osc->time -= 1.0;
		}
		if (time < 0.5) {
			value += time * 0.25;
		} else {
			value += time * 0.25 - 0.25;
		}
	}
	p_osc->value = value;
}

#endif //__OSC_H__
