#include "sampler.h"
#include "channel.h"
#include "filter.h"
#include "system_values.h"

#define TRANSITION_SPEED 0.068

Sampler::Sampler() {
}

void
Sampler::onkey(int32 port, int32 channel, int32 note, int32 velocity) {
    this->port = port;
    this->channel = channel;
    this->note = note;
    mpChannel = SystemValues.ppChannel[port * MIDI_CHANNELS + channel];
    egValue.amp = 0.0;
    egValue.vcf = mEgParam.vcf_rise;
    egValue.pitch = mEgParam.pitch_rise;
    egValue.amp_ondecay = 0;
    egValue.vcf_ondecay = 0;
    egValue.pitch_ondecay = 0;
    mFilter.res = mEgParam.vcf_resonance;
    mfpStep = &Sampler::step_pcm;
    mGain = velocity / 127.0;
    mAmp = mpChannel->vol * mpChannel->exp;
    mPanRe = mpChannel->panRe;
    mPanIm = mpChannel->panIm;
}

void
Sampler::step_pcm() {
    for (int32 i = 0; i < SystemValues.buffer_length; i++) {
        eg_step(mEgParam, &egValue);
        auto p_osc = &mOsc[0];
        p_osc->pitch = egValue.pitch * mpChannel->pitch;
        osc_pcm(p_osc);
        mFilter.cut = egValue.vcf;
        filter_lpf(&mFilter, p_osc->value);
        double outputL = mFilter.a21 * egValue.amp * mGain * mAmp;
        double outputR = outputL;

        {
            mpChannel->pWaveL[i] += outputL * mPanRe - outputR * mPanIm;
            mpChannel->pWaveR[i] += outputL * mPanIm + outputR * mPanRe;
            mAmp += (mpChannel->vol * mpChannel->exp - mAmp) * TRANSITION_SPEED;
            mPanRe += (mpChannel->panRe - mPanRe) * TRANSITION_SPEED;
            mPanIm += (mpChannel->panIm - mPanIm) * TRANSITION_SPEED;
        }
    }
}

void
Sampler::step_pwm() {
    for (int32 i = 0; i < SystemValues.buffer_length; i++) {
        eg_step(mEgParam, &egValue);
    }
}