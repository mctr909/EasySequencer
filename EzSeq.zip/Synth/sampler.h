#ifndef __SAMPLER_H__
#define __SAMPLER_H__

#include "type.h"
#include "eg.h"
#include "osc.h"
#include "filter.h"

class Channel;

class Sampler {
public:
    int32 port = -1;
    int32 channel = -1;
    int32 note = -1;
    EG_VALUE egValue = { };

private:
    void (Sampler::* mfpStep)();
    Channel* mpChannel = NULL;
    EG_PARAM mEgParam = { };
    OSC mOsc[7] = { 0 };
    FILTER mFilter = { 0 };
    double mGain = 0.0;
    double mAmp = 0.0;
    double mPanRe = 0.0;
    double mPanIm = 0.0;

public:
    Sampler();

public:
    void onkey(int32 port, int32 channel, int32 note, int32 velocity);
    inline void step() {
        if (egValue.state < EG_STATE::PRESS) {
            return;
        }
        (this->*mfpStep)();
    }

private:
    void step_pcm();
    void step_pwm();
};
#endif /* __SAMPLER_H__ */