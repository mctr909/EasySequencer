#ifndef __SYSTEM_VALUES__
#define __SYSTEM_VALUES__

#include "type.h"
#include "sampler.h"
#include "channel.h"

#define SAMPLER_COUNT 128
#define MIDI_CHANNELS 16
#define PORT_COUNT 4
#define CHANNEL_COUNT (MIDI_CHANNELS * PORT_COUNT)

typedef struct SYSTEM_VALUES {
    int32 sample_rate;
    int32 bits;
    int32 buffer_length;
    int32 buffer_count;
    double delta_time;
    byte* p_wave_table;
    double* p_wave_l;
    double* p_wave_r;
    Sampler* ppSampler[SAMPLER_COUNT];
    Channel* ppChannel[CHANNEL_COUNT];
} SYSTEM_VALUES;

static SYSTEM_VALUES SystemValues = { 0 };

#endif /* __SYSTEM_VALUES__ */