#ifndef __TYPE_H__
#define __TYPE_H__

#include <windows.h>

typedef unsigned char  byte;
typedef signed   char  sbyte;
typedef unsigned short uint16;
typedef signed   short int16;
typedef unsigned int   uint32;
typedef signed   int   int32;
typedef LPWSTR         STRING;
#endif /* __DLLMAIN_H__ */